<header class="va-l-site-header">
    <a href="index.php" class="va-c-site-logo" title="VivifyAcademy blog">
        Vivify<strong>blog</strong>
    </a>

    <nav class="va-c-site-nav">
        <a href="index.php" title="Home">Home</a>
        <a href="new_ad.php" title="Create post">Novi Oglas</a>
        <a href="new_user.php" title="Profile">Novi korisnik</a>
        <a href="new_profile.php" title="Profile">Novi profil</a>
    </nav>
</header>