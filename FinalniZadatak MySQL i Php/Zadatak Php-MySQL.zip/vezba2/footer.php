<footer class="va-l-site-footer">
    <p>Copyright &copy; 2017.</p>

    <nav>
        <a href="index.php" title="Home">Home</a>
        <a href="about.html" title="About">About</a>
        <a href="contact.html" title="Contact">Contact</a>
        <a href="admin.php" title="Admin">Admin</a>
    </nav>
</footer>